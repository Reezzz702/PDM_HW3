# RRT Planning
`python RRT.py`
# Navigate in Habitat
`python load.py -t [target]`